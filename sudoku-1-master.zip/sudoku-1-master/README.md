------------------------------------------------------------------------
This is the project README file. Here, you should describe your project.
Tell the reader (someone who does not know anything about this project)
all they need to know. The comments should usually include at least:
------------------------------------------------------------------------

PROJECT TITLE:SUDOKU
PURPOSE OF PROJECT:Simular e possibilitar a jogada de uma partida de sudoku.
VERSION or DATE:18/11/22
HOW TO START THIS PROJECT:
AUTHORS:João Pedro Weber, Pedro Ribeiro e Daniel zottisl Levin.
USER INSTRUCTIONS: O primeiro passo do jogo começa com a seleção de dificuldade que ira determinar qual matriz 9x9 com espaços em branco sera selecionada.
O segundo passo ira pedir o input do jogador para prencher com o numero selecionado no espaço em branco da coluna e linha. 
No terçeiro passo o algoritmo ira testar a soma da coluna, linha e separadamente a caixa 3x3 para ver se o numero de input do jogador não foi repitido e avisara se ajogada foi valida ou não.
